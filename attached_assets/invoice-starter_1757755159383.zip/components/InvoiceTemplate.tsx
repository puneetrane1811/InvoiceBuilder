import React from 'react'

export default function InvoiceTemplate({ invoice, org }: any) {
  return (
    <div className="bg-white p-6 rounded shadow w-full">
      <header className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold">{org?.name ?? 'Organization'}</h2>
          <div className="text-sm text-gray-600">{org?.gstin}</div>
        </div>
        {org?.logoUrl && <img src={org.logoUrl} alt="logo" className="h-14" />}
      </header>

      <section className="mb-4">
        <h3 className="font-semibold">Invoice</h3>
        <div>Number: {invoice?.invoiceNumber}</div>
        <div>Date: {invoice?.issueDate}</div>
      </section>

      <table className="w-full text-sm">
        <thead><tr><th className="text-left">Description</th><th>Qty</th><th>Unit</th><th>Total</th></tr></thead>
        <tbody>
          {invoice?.items?.map((it:any)=>(
            <tr key={it.id}>
              <td>{it.description}</td>
              <td className="text-center">{it.qty}</td>
              <td className="text-right">{it.unitPrice}</td>
              <td className="text-right">{it.lineTotal}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="text-right mt-4">
        <div>Subtotal: {invoice?.subtotal}</div>
        <div>Tax: {invoice?.taxTotal}</div>
        <div className="font-bold">Total: {invoice?.total}</div>
      </div>
    </div>
  )
}
