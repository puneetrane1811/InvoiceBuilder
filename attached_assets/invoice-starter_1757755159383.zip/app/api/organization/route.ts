import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  // TODO: add pagination, auth, org scoping
  const rows = await prisma.organization.findMany()
  return NextResponse.json(rows)
}

export async function POST(req: Request) {
  const body = await req.json()
  const rec = await prisma.organization.create({ data: body })
  return NextResponse.json(rec)
}
