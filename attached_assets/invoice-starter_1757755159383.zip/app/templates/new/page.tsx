export default function NewTemplatesPage() {
  return (
    <div>
      <h2 className="text-xl font-semibold">Create new template</h2>
      <p className="text-sm text-gray-600">Form UI to create a template goes here.</p>
    </div>
  )
}
