import Link from 'next/link'

export default function TemplatesPage() {
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Templates</h2>
        <Link href='/templates/new' className="px-3 py-2 bg-blue-600 text-white rounded">New template</Link>
      </div>
      <div className="bg-white shadow rounded p-4">
        <p className="text-sm text-gray-600">List of templates will appear here. Connect to API: <code>/api/templates</code></p>
      </div>
    </div>
  )
}
