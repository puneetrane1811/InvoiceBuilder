import Link from 'next/link'

export default function InvoicesPage() {
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Invoices</h2>
        <Link href='/invoices/new' className="px-3 py-2 bg-blue-600 text-white rounded">New invoice</Link>
      </div>
      <div className="bg-white shadow rounded p-4">
        <p className="text-sm text-gray-600">List of invoices will appear here. Connect to API: <code>/api/invoices</code></p>
      </div>
    </div>
  )
}
