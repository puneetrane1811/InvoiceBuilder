export default function NewInvoicesPage() {
  return (
    <div>
      <h2 className="text-xl font-semibold">Create new invoice</h2>
      <p className="text-sm text-gray-600">Form UI to create a invoice goes here.</p>
    </div>
  )
}
