export default function NewItemsPage() {
  return (
    <div>
      <h2 className="text-xl font-semibold">Create new item</h2>
      <p className="text-sm text-gray-600">Form UI to create a item goes here.</p>
    </div>
  )
}
