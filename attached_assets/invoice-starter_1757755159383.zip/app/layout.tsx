import './globals.css'
import React from 'react'

export const metadata = {
  title: 'Invoice Starter',
  description: 'Starter invoicing app'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen bg-gray-50">
          <header className="bg-white shadow p-4">
            <div className="max-w-6xl mx-auto">Invoice Starter</div>
          </header>
          <main className="max-w-6xl mx-auto p-6">{children}</main>
        </div>
      </body>
    </html>
  )
}
