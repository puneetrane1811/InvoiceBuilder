import Link from 'next/link'

export default function TaxesPage() {
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Taxes</h2>
        <Link href='/taxes/new' className="px-3 py-2 bg-blue-600 text-white rounded">New taxe</Link>
      </div>
      <div className="bg-white shadow rounded p-4">
        <p className="text-sm text-gray-600">List of taxes will appear here. Connect to API: <code>/api/taxes</code></p>
      </div>
    </div>
  )
}
