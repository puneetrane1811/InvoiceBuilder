export default function NewTaxesPage() {
  return (
    <div>
      <h2 className="text-xl font-semibold">Create new taxe</h2>
      <p className="text-sm text-gray-600">Form UI to create a taxe goes here.</p>
    </div>
  )
}
