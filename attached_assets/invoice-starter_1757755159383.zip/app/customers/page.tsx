import Link from 'next/link'

export default function CustomersPage() {
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Customers</h2>
        <Link href='/customers/new' className="px-3 py-2 bg-blue-600 text-white rounded">New customer</Link>
      </div>
      <div className="bg-white shadow rounded p-4">
        <p className="text-sm text-gray-600">List of customers will appear here. Connect to API: <code>/api/customers</code></p>
      </div>
    </div>
  )
}
