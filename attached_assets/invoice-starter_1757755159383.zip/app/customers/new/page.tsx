export default function NewCustomersPage() {
  return (
    <div>
      <h2 className="text-xl font-semibold">Create new customer</h2>
      <p className="text-sm text-gray-600">Form UI to create a customer goes here.</p>
    </div>
  )
}
