import Link from 'next/link'

export default function Home() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Invoice Starter</h1>
      <ul className="space-y-2">
        <li><Link href='/invoices' className="text-blue-600">Invoices</Link></li>
        <li><Link href='/items' className="text-blue-600">Items</Link></li>
        <li><Link href='/customers' className="text-blue-600">Customers</Link></li>
        <li><Link href='/taxes' className="text-blue-600">Taxes</Link></li>
        <li><Link href='/templates' className="text-blue-600">Invoice Templates</Link></li>
      </ul>
    </div>
  )
}
