# Invoice Starter (Next.js + TypeScript + Prisma)

This is a minimal starter scaffold for an invoicing application with modules:
- Invoices
- Items
- Customers
- Taxes
- Invoice PDF Templates

## Quickstart (Replit / Local)

1. Install dependencies:
```bash
npm install
```

2. Create a `.env` file from `.env.example` and set `DATABASE_URL` (Postgres).

3. Initialize Prisma:
```bash
npx prisma generate
npx prisma migrate dev --name init
```

4. Run dev server:
```bash
npm run dev
```

## Notes
- This starter provides basic pages and API routes to jumpstart development.
- Customize templates, add authentication, and connect storage (S3) for logos as needed.
